"""Vireo Audio - support performance tool. Run: streamlit run app.py"""
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

from src import metrics as mt, scoring as sc, text_analysis as ta
from src.pipeline import load_all
from src.utils import inr, pct, MIN_CSAT_RESPONSES

st.set_page_config(page_title="Vireo Audio - Support Performance", layout="wide")


@st.cache_data(show_spinner="Loading and validating data...")
def get_data():
    return load_all()


P = get_data()
T = P["t"]; goal = P["goal"]

# ---------------- sidebar filters ----------------
st.sidebar.title("Filters")
d0, d1 = T.created_at.min().date(), T.created_at.max().date()
dr = st.sidebar.date_input("Created between", (d0, d1), min_value=d0, max_value=d1)
sel = lambda label, col: st.sidebar.multiselect(label, sorted(T[col].dropna().unique()))
f_team, f_site, f_chan, f_cat = sel("Agent team", "agent_team"), sel("Site", "agent_site"), sel("Channel", "channel"), sel("Category", "category")
f_tier = st.sidebar.multiselect("Tier", [1, 2])
F = T.copy()
if len(dr) == 2:
    F = F[(F.created_at.dt.date >= dr[0]) & (F.created_at.dt.date <= dr[1])]
for col, val in [("agent_team", f_team), ("agent_site", f_site), ("channel", f_chan), ("category", f_cat), ("agent_tier", f_tier)]:
    if val:
        F = F[F[col].isin(val)]
st.sidebar.caption(f"{len(F):,} of {len(T):,} tickets selected")
st.sidebar.caption("No customer names, ids or message text are displayed anywhere in this tool.")
if F.empty:
    st.warning("No tickets match the filters."); st.stop()

K = mt.kpis(F)
AG = mt.agent_table(F)
RANK, META = sc.build_ranking(F, AG)

tabs = st.tabs(["1 Executive Summary", "2 Agent Performance", "3 Bottom 10", "4 Agent Drilldown", "5 Drivers / Themes", "6 Data Quality", "7 Validation"])

# ---------------- 1 executive ----------------
with tabs[0]:
    st.header("Who should we retrain, and why?")
    obs = sc.bottom_ten_observed(RANK); adj = sc.bottom_ten_adjusted(RANK)
    n_strong = int((RANK.evidence == "Strongest available evidence").sum()); n_mod = int((RANK.evidence == "Moderate evidence").sum())
    st.info(f"**Short answer:** {int((obs.tier == 2).sum())} of the 10 lowest raw-CSAT agents are Tier 2 warranty staff and {int(obs.team.eq('Chat Frontline').sum())} are Chat agents on the hardware-triage rota - the hardest queues. "
            f"After adjusting for case mix and sample size, {n_strong} agent(s) show the strongest available evidence of being below peers (P>=90%) and {n_mod} show moderate evidence; the rest are statistically indistinguishable. "
            f"Agent-to-agent spread is small (SD {META['tau']:.2f} CSAT points). The bigger money is a product-lot problem, not people.")
    a, b, c, d = st.columns(4)
    a.metric("Tickets", f"{K['tickets']:,}"); b.metric("CSAT response rate", pct(K["csat_response_rate"]), f"{K['csat_responses']:,} responses")
    c.metric("Average CSAT (blanks excluded)", f"{K['avg_csat']:.2f}"); d.metric("Median handle time", f"{K['median_handle_h']*60:.0f} min")
    a, b, c, d = st.columns(4)
    a.metric("First-response breach rate", pct(K["breach_rate"]), f"{inr(K['breach_credit_inr'])} credits")
    b.metric("Repeat-contact rate (30d)", pct(K["repeat_rate"]), f"{K['repeat_evaluable']:,} evaluable", delta_color="off")
    c.metric("Replacement rate", pct(K["replacement_rate"]), f"{K['replacements']:,} replacements", delta_color="off")
    d.metric("Replacement cost (policy: unit cost + Rs 340)", inr(K["replacement_cost_inr"]))
    a, b, c, d = st.columns(4)
    a.metric("Refunds raised", f"{K['refunds']:,}", inr(K["refund_inr"]), delta_color="off")
    b.metric("Transfer rate (helpdesk only)", pct(K["transfer_rate_helpdesk"]), f"{inr(K['transfer_cost_inr'])} @ Rs 305", delta_color="off")
    c.metric("Contact cost (fully loaded)", inr(K["contact_cost_inr"]))
    d.metric("Avg replacement cost", inr(goal["avg_replacement_cost_all"]), f"Finance assumed Rs 2,500", delta_color="off")
    st.subheader("Business goal")
    pq = goal["per_quarter"]
    st.success(f"**Cut the replacement rate on {goal['product']} lots {', '.join(goal['lots'])} from {pct(goal['bad_rate'])} to {pct(goal['baseline_rate'])}** "
               f"(the rate on that product's other lots). Excess = {goal['excess_replacements']:.0f} replacements x {inr(goal['cost_each'])} (unit {inr(goal['unit_cost'])} + Rs 340) = **{inr(goal['excess_cost_inr'])}** over 18 months; "
               f"**{inr(goal['peak_quarter_excess_cost'])} in the peak quarter ({goal['peak_quarter']})**, {inr(pq.excess_cost_inr.iloc[-1])} in the latest quarter.")
    q = mt.quarterly(F)
    c1, c2 = st.columns(2)
    fig = px.bar(q, x="quarter", y="replacement_cost_inr", title="Replacement cost by quarter (policy formula)"); c1.plotly_chart(fig, use_container_width=True)
    fig = px.line(q, x="quarter", y=["replacement_rate"], markers=True, title="Replacement rate by quarter"); fig.update_yaxes(tickformat=".0%"); c2.plotly_chart(fig, use_container_width=True)
    lot = T[(T.product_sku == goal["sku"]) & T.lot_month.notna()].groupby("lot_month").agg(tickets=("ticket_id", "size"), rate=("replaced", "mean")).reset_index()
    fig = px.bar(lot, x="lot_month", y="rate", hover_data=["tickets"], title=f"{goal['product']}: replacement rate by manufacturing lot (YYMM)"); fig.update_yaxes(tickformat=".0%")
    st.plotly_chart(fig, use_container_width=True)
    st.caption("Replacement flag is the agent-set Y/N. 496 notes mention a replacement while the flag is N (see Data Quality), so costs may be understated.")

# ---------------- 2 agent performance ----------------
with tabs[1]:
    st.header("Agent performance (joined on agent_id)")
    st.caption("Tier 2 handle time is shown in days and Tier 2 volume is not comparable with Tier 1 (policy s6). CSAT average uses responses only.")
    tier_view = st.radio("Tier", ["Tier 1", "Tier 2", "Both"], horizontal=True)
    A = AG if tier_view == "Both" else AG[AG.tier == int(tier_view[-1])]
    show = A[["agent_name", "agent_id", "team", "site", "shift", "tier", "tickets", "attended", "csat_n", "csat_avg", "csat_pct_1_2", "csat_pct_4_5", "median_handle_h", "breach_rate", "transfer_rate", "replacement_rate", "hardware_share"]].copy()
    show["median_handle_h"] = np.where(show.tier == 2, show.median_handle_h / 24, show.median_handle_h)
    show = show.rename(columns={"median_handle_h": "median_handle (h; days for Tier 2)"})
    st.dataframe(show.sort_values("csat_avg"), use_container_width=True, hide_index=True,
                 column_config={"csat_avg": st.column_config.NumberColumn(format="%.2f"), "breach_rate": st.column_config.NumberColumn(format="%.1f%%" if False else "%.3f"),
                                "csat_pct_1_2": st.column_config.NumberColumn(format="%.2f"), "csat_pct_4_5": st.column_config.NumberColumn(format="%.2f"),
                                "median_handle (h; days for Tier 2)": st.column_config.NumberColumn(format="%.2f"), "transfer_rate": st.column_config.NumberColumn(format="%.3f"),
                                "replacement_rate": st.column_config.NumberColumn(format="%.3f"), "hardware_share": st.column_config.NumberColumn(format="%.2f")})
    fig = px.scatter(A, x="hardware_share", y="csat_avg", size="csat_n", color="team", hover_name="agent_name", hover_data=["agent_id"],
                     title="Raw CSAT falls with hardware exposure: the queue, not only the person")
    st.plotly_chart(fig, use_container_width=True)
    fig = px.box(A, x="team", y="csat_avg", points="all", hover_name="agent_name", title="Agent CSAT spread within each team")
    st.plotly_chart(fig, use_container_width=True)

# ---------------- 3 bottom 10 ----------------
with tabs[2]:
    st.header("Bottom ten - two different questions")
    st.markdown(f"""
**A. Lowest observed CSAT** answers *'who has the lowest average score?'* - it mostly measures the queue.
**B. Strongest evidence of an agent-level training opportunity** answers *'who scores below peers after the queue is accounted for?'*
Method: expected CSAT per ticket from a regression on category, channel, priority, first-routed team, breach, transfer, legacy flag and the defective-lot terms
(open/pending tickets, blanks and {int(F.junk_message.sum())} junk transcripts excluded) -> agent mean residual -> **empirical-Bayes shrinkage** (between-agent SD estimated at {META['tau']:.3f} CSAT points; DerSimonian-Laird) ->
probability the agent's true effect is below peers. Agents need >= {MIN_CSAT_RESPONSES} scored responses.""")
    cols = ["agent_name", "agent_id", "team", "tier", "csat_n", "csat_avg", "hardware_share", "expected_csat", "adj_effect", "shrunk_effect", "p_below_peers", "evidence"]
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("A. Lowest observed CSAT (raw)")
        st.dataframe(sc.bottom_ten_observed(RANK)[["agent_name", "agent_id", "team", "tier", "csat_n", "csat_avg", "hardware_share"]], hide_index=True, use_container_width=True)
        st.caption(f"Do NOT use for retraining decisions: {int((sc.bottom_ten_observed(RANK).tier == 2).sum())} of these 10 are Tier 2 warranty staff (hardest queue, certified work).")
    with c2:
        st.subheader("B. Training-priority view (adjusted + shrunk)")
        bt = sc.bottom_ten_adjusted(RANK)
        st.dataframe(bt[cols[:3] + ["csat_n", "adj_effect", "shrunk_effect", "p_below_peers", "evidence"]], hide_index=True, use_container_width=True)
        st.caption("adj_effect = CSAT points vs case-mix expectation; shrunk_effect = after shrinkage toward 0; evidence tier from P(below peers).")
    ov = bt.merge(RANK[["agent_id", "raw_rank"]], on="agent_id", suffixes=("", "_r"))
    fig = px.scatter(RANK[RANK.eligible.fillna(False)], x="adj_effect", y="csat_avg", color="team", size="csat_n", hover_name="agent_name",
                     title="Raw CSAT vs case-mix-adjusted effect (left = below peers)")
    st.plotly_chart(fig, use_container_width=True)
    st.subheader("Training recommendations for the adjusted bottom ten")
    recs = pd.DataFrame([sc.recommend(F, RANK, a) for a in bt.agent_id])
    st.dataframe(recs.rename(columns=str.title), hide_index=True, use_container_width=True)
    st.caption("Correlation only: these show where an agent differs from peers, not why. Confirm with call/chat listen-ins before any action.")
    st.subheader("Top five (Diwali bonus) - same adjusted method")
    st.dataframe(sc.top_five_adjusted(RANK)[["agent_name", "agent_id", "team", "csat_n", "csat_avg", "adj_effect", "p_above_peers"]], hide_index=True, use_container_width=True)
    st.caption("A raw-CSAT top five would reward Billing/Email/Voice agents with easy queues; none of these differences is statistically strong, so treat the bonus list as a tie-break among near-equals.")

# ---------------- 4 drilldown ----------------
with tabs[3]:
    st.header("Agent drill-down")
    lab = {r.agent_id: f"{r.agent_name} ({r.agent_id}) - {r.team}" for r in AG.itertuples()}
    aid = st.selectbox("Agent", list(lab), format_func=lambda x: lab[x])
    r = RANK[RANK.agent_id == aid].iloc[0]; g = F[F.agent_id == aid]
    peers = RANK[(RANK.team == r.team) & (RANK.agent_id != aid)]
    st.subheader(f"{r.agent_name} - {r.team}, Tier {r.tier}, {r.site}, {r.shift} shift")
    m = st.columns(6)
    m[0].metric("Tickets", f"{r.tickets:,}", f"{r.attended:,} attended"); m[1].metric("CSAT", f"{r.csat_avg:.2f}", f"team {peers.csat_avg.mean():.2f}", delta_color="off")
    m[2].metric("CSAT responses", int(r.csat_n)); m[3].metric("Breach rate", pct(r.breach_rate), f"team {pct(peers.breach_rate.mean())}", delta_color="off")
    hh = r.median_handle_h / 24 if r.tier == 2 else r.median_handle_h
    m[4].metric("Median handle", f"{hh:.1f} {'days' if r.tier == 2 else 'h'}"); m[5].metric("Replacement / refund", f"{pct(r.replacement_rate)} / {pct(r.refund_rate)}")
    if r.eligible and not pd.isna(r.adj_effect):
        st.write(f"**Case-mix adjusted effect:** {r.adj_effect:+.2f} CSAT points (expected {r.expected_csat:.2f}); shrunk {r.shrunk_effect:+.2f}; P(below peers) {r.p_below_peers:.0%}; evidence: **{r.evidence}**.")
    st.json(sc.recommend(F, RANK, aid), expanded=False)
    c1, c2 = st.columns(2)
    dist = g.csat_score.dropna().astype(int).value_counts().reindex(range(1, 6), fill_value=0).reset_index(); dist.columns = ["csat", "responses"]
    c1.plotly_chart(px.bar(dist, x="csat", y="responses", title="CSAT distribution"), use_container_width=True)
    c2.plotly_chart(px.pie(g, names="channel", title="Channel mix"), use_container_width=True)
    c1, c2 = st.columns(2)
    cm = g.category.value_counts().reset_index(); cm.columns = ["category", "tickets"]
    c1.plotly_chart(px.bar(cm, x="tickets", y="category", orientation="h", title="Category mix"), use_container_width=True)
    th = ta.theme_table(g)
    c2.plotly_chart(px.bar(th, x="tickets", y="theme", orientation="h", title="Customer-message themes (NLP)"), use_container_width=True)
    st.write(f"**Replacement/refund involvement:** {int(g.replaced.sum())} replacements ({inr(g.replacement_cost_inr.sum())} at policy cost), {int(g.refunded.sum())} refunds ({inr(g.refund_amount_inr.sum())}), "
             f"{int(g.bad_lot.sum())} tickets on defective Pulse 2 lots.")
    st.write("**Distinctive terms in this agent's customer messages (TF-IDF):** " + ", ".join(ta.top_terms(g, 12)))
    ex = g[~g.junk_message].groupby("theme").agg(tickets=("ticket_id", "size"), avg_csat=("csat_score", "mean"), example_ticket=("ticket_id", "first")).sort_values("tickets", ascending=False).head(6).reset_index()
    st.dataframe(ex, hide_index=True, use_container_width=True)
    st.caption("Example ticket ids only; message text is withheld to avoid showing customer names and order numbers.")

# ---------------- 5 drivers ----------------
with tabs[4]:
    st.header("What drives low CSAT, long handle times and cost?")
    th = ta.theme_table(F)
    c1, c2 = st.columns(2)
    c1.plotly_chart(px.bar(th.sort_values("csat"), x="csat", y="theme", orientation="h", title="Average CSAT by theme (responses only)"), use_container_width=True)
    c2.plotly_chart(px.bar(th.sort_values("replaced"), x="replaced", y="theme", orientation="h", title="Replacement rate by theme"), use_container_width=True)
    st.dataframe(th.round(2), hide_index=True, use_container_width=True)
    S = F[F.has_csat & F.attended]
    eff = pd.DataFrame({"factor": ["First-response breach", "Transferred", "Defective Pulse 2 lot", "Angry wording", "Hardware category"],
                        "CSAT with factor": [S[S.breach].csat_score.mean(), S[S.transfers > 0].csat_score.mean(), S[S.bad_lot].csat_score.mean(), S[S.angry].csat_score.mean(), S[S.hw_category].csat_score.mean()],
                        "CSAT without": [S[~S.breach].csat_score.mean(), S[S.transfers == 0].csat_score.mean(), S[~S.bad_lot].csat_score.mean(), S[~S.angry].csat_score.mean(), S[~S.hw_category].csat_score.mean()]})
    eff["difference"] = eff.iloc[:, 1] - eff.iloc[:, 2]
    st.subheader("Raw CSAT gaps (unadjusted; factors overlap)"); st.dataframe(eff.round(2), hide_index=True, use_container_width=True)
    bs = F.groupby("agent_shift").breach.mean().reset_index(); st.plotly_chart(px.bar(bs, x="agent_shift", y="breach", title="Breach rate by resolving agent's shift (Night is highest: coverage, not only people)").update_yaxes(tickformat=".0%"), use_container_width=True)
    st.markdown(f"**NLP method.** Rule lexicon seeded from TF-IDF term inspection + a char-n-gram logistic regression trained on confidently rule-labelled tickets to rescue misspelt messages. Held-out agreement with rules: **{P['info']['heldout_agreement']:.1%}**. "
                f"Rule-labelled {P['info']['rule_labelled']:,}; ML-fallback {P['info']['ml_labelled']:,}; unclassified {P['info']['unclassified']:,}; junk {P['info']['junk']}. No paid API calls; cost to run is Rs 0.")

# ---------------- 6 DQ ----------------
with tabs[5]:
    st.header("Data quality"); st.caption("Nothing was silently deleted. Rows are flagged and the treatment is stated.")
    st.dataframe(P["dq"], hide_index=True, use_container_width=True)

# ---------------- 7 validation ----------------
with tabs[6]:
    st.header("Validation"); v = P["val"]
    st.success(f"{int((v.result == 'PASS').sum())}/{len(v)} automated validation checks passed (independent csv/datetime re-computation vs pipeline). Also run `pytest`.")
    st.dataframe(v, hide_index=True, use_container_width=True)
    st.markdown("**How often is the tool wrong?** Arithmetic metrics reproduce an independent calculation exactly (0 differences on the records tested). Statistical outputs (bottom ten, themes) have uncertainty that is shown, not hidden: "
                f"theme classifier agreement with its rule labels is {P['info']['heldout_agreement']:.1%} on held-out tickets (this is agreement, not accuracy against human labels - none exist); bottom-ten membership is uncertain because the between-agent SD is only {META['tau']:.2f} CSAT points.")
