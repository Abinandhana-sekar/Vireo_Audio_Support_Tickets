# Final checklist

| Requirement | Status | Evidence |
|---|---|---|
| Working AI-assisted tool (local NLP, no paid calls) | PASS | `streamlit run app.py` returns HTTP 200 and health "ok"; AppTest ran all 7 tabs, filters and drill-down with no exceptions |
| Business goal as a number | PASS | Pulse 2 lots 2510-12 replacement rate 37.4% -> 11.4%; Rs 12.1 lakh / 18 months, Rs 8.8 lakh peak quarter (reports/methodology.md) |
| Correctness / validation | PASS | 25/25 independent checks; 37/37 pytest tests (re-run from the extracted ZIP) |
| Bottom ten without raw ranking (two lists, shrinkage, Tier/queue aware) | PASS | Bottom 10 tab, src/scoring.py |
| Data-quality report, nothing silently deleted | PASS | reports/data_quality.md |
| One-page memo to Priya (md + pdf) | PASS | memo_to_priya.pdf = 1 page, about 500 words |
| <=3 minute video script | PASS | screen_recording_script.md (script only) |
| Screen recording itself | ACTION REQUIRED | Not recordable by the assistant; record following the script |
| Prompts used | PASS | prompts_used.md |
| Changes between versions | PASS | ai_usage.md, submission-form.md s5 |
| Discarded approaches | PASS | ai_usage.md "Rejected / discarded" |
| Completed submission form | PASS except 4 personal fields | Answers written to the official questions; you must paste Drive link, video link, GitHub URL and your hours |
| Decisions documented | PASS | DECISIONS.md (16 decisions) |
| README clean-machine setup | PASS | venv + pip + streamlit + pytest steps (dependencies verified by import; a fresh-internet pip install was not run) |
| No secrets / PII displayed | PASS | scan found none; app shows no customer ids, names or messages |
| ZIP created | PASS | Vireo_Audio_Support_Tickets_Set_B_Submission.zip |
| Mapping 'Kavya's four' = A3004-A3007 | INFERRED | Not confirmed by client |
| ~40 junk IVR transcripts | PARTIAL | only 17 verifiably empty |
