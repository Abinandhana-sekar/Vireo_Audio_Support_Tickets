import sys
from pathlib import Path
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.pipeline import load_all


@pytest.fixture(scope="session")
def P():
    return load_all()
