import numpy as np
import pandas as pd
from src import scoring as sc, metrics as mt


def test_dl_tau2_zero_when_homogeneous():
    eff = np.array([0.0, 0.01, -0.01, 0.0]); se = np.array([0.1] * 4)
    assert sc.dersimonian_laird_tau2(eff, se) == 0.0


def test_dl_tau2_positive_when_heterogeneous():
    assert sc.dersimonian_laird_tau2(np.array([-0.5, 0.5, -0.4, 0.4]), np.array([0.05] * 4)) > 0


def test_shrinkage_pulls_small_samples_more(P):
    r = P["ranking"]; r = r[r.eligible]
    assert (r.shrunk_effect.abs() <= r.adj_effect.abs() + 1e-12).all()
    small, large = r.nsmallest(5, "n_scored"), r.nlargest(5, "n_scored")
    assert small.shrinkage.mean() < large.shrinkage.mean()


def test_bottom_ten_adjusted_is_ten_sorted_and_eligible(P):
    bt = sc.bottom_ten_adjusted(P["ranking"])
    assert len(bt) == 10 and bt.agent_id.is_unique and bt.eligible.all() and bt.shrunk_effect.is_monotonic_increasing


def test_observed_and_adjusted_lists_differ(P):
    a, b = set(sc.bottom_ten_observed(P["ranking"]).agent_id), set(sc.bottom_ten_adjusted(P["ranking"]).agent_id)
    assert a != b and len(a & b) < 8


def test_tier2_dominates_raw_but_not_adjusted_bottom(P):
    raw = sc.bottom_ten_observed(P["ranking"]); adj = sc.bottom_ten_adjusted(P["ranking"])
    assert (raw.tier == 2).sum() >= 5 and (adj.tier == 2).sum() <= 2


def test_two_kavya_pandey_are_separate(P):
    r = P["ranking"]; k = r[r.agent_name == "Kavya Pandey"]
    assert set(k.agent_id) == {"A3006", "A3029"} and k.team.nunique() == 2


def test_min_response_threshold_enforced(P):
    t = P["t"]; a = mt.agent_table(t)
    r, _ = sc.build_ranking(t, a, min_n=10_000)
    assert not r.eligible.any() and (r.evidence == "Insufficient data").all()


def test_junk_and_open_excluded_from_scoring_sample(P):
    d = sc.scoring_sample(P["t"])
    assert not d.junk_message.any() and d.attended.all() and d.has_csat.all()


def test_recommendation_has_required_fields(P):
    r = sc.recommend(P["t"], P["ranking"], "A3004")
    assert set(r) == {"agent", "issue", "evidence", "context", "training", "confidence"}
