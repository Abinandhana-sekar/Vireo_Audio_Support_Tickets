from src import validation as vd, metrics as mt, text_analysis as ta


def test_independent_recomputation_all_pass(P):
    v = P["val"]; assert len(v) >= 25 and (v.result == "PASS").all(), v[v.result != "PASS"]


def test_goal_arithmetic_and_policy_cost(P):
    g = P["goal"]
    assert g["cost_each"] == g["unit_cost"] + 340 == 1820 and g["finance_assumed_cost"] != g["cost_each"]
    assert abs(g["excess_cost_inr"] - g["excess_replacements"] * 1820) < 1e-6
    assert g["lots"] == ["2510", "2511", "2512"] and g["sku"] == "VA-EB-PL2"
    assert g["bad_rate"] > 2.5 * g["baseline_rate"]


def test_lot_detection_is_data_driven_and_finds_only_pl2(P):
    an = mt.detect_lot_anomalies(P["t"]); assert set(an.product_sku) == {"VA-EB-PL2"} and len(an) == 3


def test_theme_classifier_agreement_reported_and_high(P):
    assert P["info"]["heldout_agreement"] > 0.9


def test_theme_rules_edge_cases():
    assert ta.rule_theme("my order arrived damaged") == "Damaged / wrong item"
    assert ta.rule_theme("want to cancel my order") == "Cancellation"
    assert ta.rule_theme("") is None


def test_no_theme_assigned_to_junk(P):
    t = P["t"]; assert (t[t.junk_message].theme == "Junk / empty message").all()


def test_validation_summary_string(P):
    assert vd.summary(P["val"]).endswith("automated validation checks passed")
