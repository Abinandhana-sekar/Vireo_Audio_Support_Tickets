import numpy as np
import pandas as pd
from src import data_loader as dl, metrics as mt, utils as U


def mini(rows):
    base = dict(ticket_id="T", created_at="2026-01-01 10:00", first_response_at="2026-01-01 10:10", resolved_at="2026-01-01 11:10",
                status="resolved", channel="chat", customer_id="C1", order_id=None, product_sku="VA-EB-PL2", category="Other", priority="Normal",
                assigned_team="Chat Frontline", agent_id="A1", transfers=0, csat_score=np.nan, refund_amount_inr=np.nan, refund_reason_code=None,
                replacement_issued="N", customer_message="hello", agent_notes="x", source_system="helpdesk")
    df = pd.DataFrame([{**base, **r, "ticket_id": f"T{i}"} for i, r in enumerate(rows)])
    return df


def build_mini(rows):
    raw = {"tickets": mini(rows),
           "agents": pd.DataFrame([dict(agent_id="A1", name="X", site="Indore", team="Chat Frontline", shift="Day", tier=1, from_date="2025-01-01", to_date=None)]),
           "orders": pd.DataFrame(columns=["order_id", "customer_id", "sku", "order_date", "channel", "qty", "order_value_inr", "lot_code"]),
           "customers": pd.DataFrame(), "products": pd.DataFrame([dict(sku="VA-EB-PL2", product_name="P", family="f", unit_cost_inr=1480, retail_price_inr=3000, warranty_months=12)])}
    return dl.build(raw=raw)


def test_sla_boundaries_per_channel():
    rows = [dict(channel="chat", first_response_at="2026-01-01 10:15"), dict(channel="chat", first_response_at="2026-01-01 10:16"),
            dict(channel="voice", first_response_at="2026-01-01 12:00"), dict(channel="voice", first_response_at="2026-01-01 12:01"),
            dict(channel="social", first_response_at="2026-01-01 14:00"), dict(channel="email", first_response_at="2026-01-01 18:01")]
    t = build_mini(rows)
    assert t.breach.tolist() == [False, True, False, True, False, True]
    assert t.breach_credit_inr.sum() == 3 * 350


def test_handle_time_is_first_response_to_resolution():
    t = build_mini([dict()])
    assert t.handle_min.iloc[0] == 60 and t.first_response_min.iloc[0] == 10


def test_legacy_resolved_at_is_utc_converted_to_ist():
    # resolved 05:40 UTC == 11:10 IST -> 60 min after 10:10 first response
    t = build_mini([dict(source_system="legacy_fd", resolved_at="2026-01-01 05:40")])
    assert t.handle_min.iloc[0] == 60


def test_csat_blank_excluded_not_zero():
    t = build_mini([dict(csat_score=5), dict(csat_score=np.nan), dict(csat_score=3)])
    k = mt.kpis(t)
    assert k["avg_csat"] == 4.0 and k["csat_responses"] == 2 and abs(k["csat_response_rate"] - 2 / 3) < 1e-12


def test_attendance_includes_resolved_and_closed_only():
    t = build_mini([dict(status="resolved"), dict(status="closed"), dict(status="open", resolved_at=None), dict(status="pending", resolved_at=None)])
    assert t.attended.tolist() == [True, True, False, False]


def test_out_of_range_csat_becomes_missing():
    t = build_mini([dict(csat_score=7), dict(csat_score=0), dict(csat_score=4)])
    assert t.csat_score.notna().sum() == 1


def test_replacement_cost_uses_policy_formula_not_finance_estimate():
    t = build_mini([dict(replacement_issued="Y"), dict()])
    assert t.replacement_cost_inr.tolist() == [1480 + 340, 0]


def test_transfer_and_contact_costs():
    t = build_mini([dict(transfers=2, channel="voice", first_response_at="2026-01-01 10:10")])
    assert t.transfer_cost_inr.iloc[0] == 610 and t.contact_cost_inr.iloc[0] == 520


def test_repeat_contact_30_day_window():
    rows = [dict(created_at="2025-01-01 10:00", first_response_at="2025-01-01 10:05", resolved_at="2025-01-01 11:00", customer_id="C1"),
            dict(created_at="2025-01-20 10:00", first_response_at="2025-01-20 10:05", resolved_at="2025-01-20 11:00", customer_id="C1"),
            dict(created_at="2025-01-01 10:00", first_response_at="2025-01-01 10:05", resolved_at="2025-01-01 11:00", customer_id="C2"),
            dict(created_at="2025-03-01 10:00", first_response_at="2025-03-01 10:05", resolved_at="2025-03-01 11:00", customer_id="C2"),
            dict(created_at="2026-06-30 10:00", first_response_at="2026-06-30 10:05", resolved_at="2026-06-30 11:00", customer_id="C3")]
    t = build_mini(rows)
    assert t.repeat_contact.tolist()[:4] == [True, False, False, False]
    assert not t.repeat_evaluable.iloc[4]  # window not fully observed -> not evaluable


def test_junk_message_detection():
    assert dl.is_junk_message("[IVR transcript] ...") and dl.is_junk_message("-") and not dl.is_junk_message("battery not charging")


def test_kpis_on_real_data(P):
    k = mt.kpis(P["t"])
    assert k["tickets"] == 11750 and k["csat_responses"] == 5196 and k["breaches"] == 1064
    assert abs(k["avg_csat"] - 3.3266) < 1e-3
