import pandas as pd
from src import data_loader as dl
from tests.test_metrics import build_mini


def test_roster_join_uses_agent_id_not_name(P):
    ag = P["raw"]["agents"]; assert ag.name.duplicated().any() and not ag.agent_id.duplicated().any()
    t = P["t"]; k = t[t.agent_id.isin(["A3006", "A3029"])]
    assert k.groupby("agent_id").agent_team.first().to_dict() == {"A3006": "Chat Frontline", "A3029": "Logistics"}


def test_roster_asof_picks_row_covering_ticket_date():
    ag = pd.DataFrame([dict(agent_id="A1", name="X", site="Indore", team="Chat Frontline", shift="Night", tier=1, from_date="2025-01-01", to_date="2025-12-31"),
                       dict(agent_id="A1", name="X", site="Bengaluru", team="Chat Frontline", shift="Day", tier=1, from_date="2026-01-01", to_date=None)])
    tk = pd.DataFrame(dict(ticket_id=["a", "b"], agent_id=["A1", "A1"], created_at=pd.to_datetime(["2025-06-01", "2026-03-01"])))
    r = dl.roster_asof(tk, ag).set_index("ticket_id")
    assert r.loc["a", "agent_site"] == "Indore" and r.loc["b", "agent_site"] == "Bengaluru" and r.roster_covers_date.all()


def test_no_duplicate_ticket_ids_and_no_row_loss(P):
    assert P["t"].ticket_id.is_unique and len(P["t"]) == len(P["raw"]["tickets"])


def test_no_negative_handle_time_after_legacy_fix(P):
    t = P["t"]; assert (t.handle_min.dropna() >= 0).all()
    raw = P["raw"]["tickets"]
    rawneg = ((pd.to_datetime(raw.resolved_at) - pd.to_datetime(raw.first_response_at)).dt.total_seconds() < 0)
    assert rawneg.sum() > 0 and (raw[rawneg].source_system == "legacy_fd").all()


def test_open_pending_have_no_handle_time(P):
    t = P["t"]; assert t[~t.attended].handle_min.isna().all()


def test_fallback_join_recovers_lot_codes(P):
    t = P["t"]; assert (t.join_method == "customer+sku fallback").sum() > 3000 and t.lot_code.notna().mean() > 0.99


def test_every_ticket_has_roster_row(P):
    assert P["t"].agent_team.notna().all() and P["t"].roster_covers_date.all()


def test_dq_report_lists_all_key_checks(P):
    names = " ".join(P["dq"].check)
    for k in ["Duplicate ticket_id", "negative handle time", "CSAT outside 1-5", "Junk", "Refund AND replacement", "Legacy"]:
        assert k.lower() in names.lower()


def test_pii_columns_not_in_agent_outputs(P):
    assert not {"customer_id", "customer_message", "name", "city"} & set(P["ranking"].columns)
