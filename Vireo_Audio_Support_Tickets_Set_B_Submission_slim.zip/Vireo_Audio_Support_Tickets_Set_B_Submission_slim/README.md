# Vireo Audio - Support Tickets (Set B): CSAT / handle-time tool

A local, free (no API calls) Streamlit tool that answers *"who should we retrain, and why?"* from the Vireo support export.
Headline: the raw bottom ten is mostly Tier 2 warranty + the Chat hardware-triage rota (queue effect). After case-mix adjustment and empirical-Bayes shrinkage only one agent reaches 90% evidence. The largest measurable money is a defective-lot problem (Pulse 2 lots 2510-12): Rs 12.1 lakh excess replacement cost, Rs 8.8 lakh in Q1-2026.
Read `memo_to_priya.md` first (one page).

## Prerequisites
Python 3.10+ (tested on 3.12), ~1 GB free RAM, no internet needed at run time (only for `pip install`).

## Installation
```bash
python -m venv .venv
# Windows:  .venv\Scripts\activate
# macOS/Linux:  source .venv/bin/activate
pip install -r requirements.txt
```

## Data placement
The supplied files are already in `data/` under the names the code expects:
`tickets.csv agents.csv orders.csv customers.csv products.csv` (plus `support-policy.pdf`, `email-thread.txt`, `README_pack.txt` for reference).
To use a refreshed export, overwrite the five CSVs keeping the same columns.

## Run
```bash
streamlit run app.py
```
Opens http://localhost:8501. Expect: 7 tabs (Executive Summary, Agent Performance, Bottom 10, Agent Drilldown, Drivers/Themes, Data Quality, Validation); first load takes ~10 s, then results are cached. Sidebar filters: date, team, site, tier, channel, category.

## Test
```bash
python -m pytest            # expect: 37 passed
python -m src.reporting     # regenerates reports/*.md (expect "reports written")
python -m src.memo_pdf      # regenerates memo_to_priya.pdf from the .md
```
The Validation tab also shows 25/25 independent-recomputation checks.

## Project structure
```
app.py                 Streamlit UI (7 tabs)
src/data_loader.py     load, legacy UTC->IST fix, roster as-of join, order/lot join, repeat contacts, DQ checks
src/metrics.py         KPIs, quarterly costs, agent table, lot-anomaly detection, business-goal arithmetic
src/scoring.py         case-mix model, empirical-Bayes shrinkage, bottom-ten lists, training recommendations
src/text_analysis.py   TF-IDF-seeded theme lexicon + char-n-gram classifier, anger/escalation cues
src/validation.py      independent csv/datetime re-computation of headline numbers
src/pipeline.py        one call that runs everything;  src/reporting.py, src/memo_pdf.py  document generators
tests/                 37 pytest tests;  reports/  data quality, validation, methodology
DECISIONS.md  ai_usage.md  prompts_used.md  screen_recording_script.md  submission-form.md  FINAL_CHECKLIST.md
```

## Methodology (short; full detail in reports/methodology.md and DECISIONS.md)
Policy v3.2 is the source of truth (SLA targets, Rs 350 credits, replacement = unit cost + Rs 340). Legacy `resolved_at` is UTC and is shifted +5h30. Joins use `agent_id` only (two agents are named Kavya Pandey). CSAT blanks are excluded. Bottom ten: expected-CSAT regression -> agent residual -> empirical-Bayes shrinkage -> P(below peers). No customer names, ids or message text are displayed.

## Known limitations
- Observational data: differences between agents show association, not cause.
- Between-agent spread is small (SD ~0.05 CSAT); bottom-ten membership is uncertain by design.
- Repeat contact uses same customer + same product as a proxy for "same issue".
- The replacement flag is agent-entered and disagrees with 496 notes; 4,015 tickets had no order_id and use a customer+SKU fallback join for lot attribution.
- Only 17 junk transcripts are verifiably empty (Sameer estimated ~40); others could not be identified.
- Theme classifier agreement (98%) is against its own rules, not human labels.
- No video is included, only the script.
