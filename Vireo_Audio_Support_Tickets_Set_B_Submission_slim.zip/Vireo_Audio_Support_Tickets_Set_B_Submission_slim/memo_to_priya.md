**To:** Priya Raman, Head of Customer Experience  **From:** Kabir Nanda  **Date:** 6 Oct 2026  **Re:** CSAT dashboard — who to retrain, and what it is really worth

**Finding.** The bottom ten by raw CSAT is the wrong retraining list. Six of the ten are Tier 2 warranty staff and four are the Chat hardware-triage rota (A3004–A3007) — the angriest queues by design. After adjusting for the mix of tickets each agent gets and for small samples, agents differ by only ±0.05 CSAT points. Only one (A3004) clears a 90% evidence bar; six more are "moderate". The CSAT slide is mostly a product problem too: Jan-Mar 2026 CSAT was 3.07 overall but 3.48 on tickets not involving the defective lots, in line with 2025 (3.4-3.6). The larger money is the same product problem, not people.

**Goal (one number).** Cut the replacement rate on **Pulse 2 earbuds from manufacturing lots 2510–2512 from 37.4% to 11.4%** (the rate on that product's other lots). Excess = 666 replacements × Rs 1,820 (unit cost Rs 1,480 + Rs 340, per policy) = **Rs 12.1 lakh over 18 months, Rs 8.8 lakh in Jan–Mar 2026 alone, Rs 2.3 lakh in the latest quarter.** Arjun's Rs 2,500 per replacement is too high; Rs 1,820 is the policy figure (actual average Rs 1,802).

**Baseline.** 11,750 tickets; CSAT 3.33 (44% respond; blanks excluded); 9.1% first-response breaches (Rs 3.7 lakh in credits); 22% repeat contact; replacement rate 16%, Rs 34 lakh total. Q1-26 tickets rose 37% on Q4-25 but replacements rose 182%, so festive volume does not explain it.

**Who needs attention.** Priority: **Siddharth Kapoor (A3004)**. Moderate evidence: A3007, A3006 (Kavya Pandey, Chat), A3041, A3022, A3020, A3029 (the other Kavya Pandey, Logistics). Each profile lists the metric that differs from peers. Differences are small; confirm by listening to chats before any action.

**Caveats.** 40% of the Chat rota's tickets involve the defective lots, and their CSAT on those tickets is 2.2 vs 3.5 for other Chat agents on the same lots. Tier 2 is measured on resolution days, not volume. Handle time and breaches are partly queue/shift effects (Night shift breaches 13% vs 8% Day). Two agents are both named Kavya Pandey; we always join on agent ID. The replacement flag is agent-entered; 496 notes mention a replacement while it says N, so real cost may be up to Rs 8.9 lakh higher. This is correlation, not proof that any agent caused a score.

**Q3 Rs 4 lakh.** Spend no more than Rs 1 lakh now: a triage-before-replace and de-escalation workshop for the seven agents above and the Chat hardware rota (their time is only about Rs 18,000 at Rs 165/hour; the rest is an assumed trainer fee). Hold Rs 3 lakh until Operations puts a quality hold on lots 2510–12 and claims on the supplier, then re-measure after six weeks. Treat the Diwali top five as a tie-break among near-equals; no agent is clearly better than peers.

**Monitor.** Replacement rate on those lots; case-mix-adjusted CSAT per agent; breach rate by shift; repeat-contact rate; replacement flag vs note mismatches.

**Out of scope.** Root-causing the defect (needs Quality/engineering), staffing models, per-ticket AI scoring (Rs 5 × 12,000 tickets avoided; this tool runs free), customer-level personal data.
