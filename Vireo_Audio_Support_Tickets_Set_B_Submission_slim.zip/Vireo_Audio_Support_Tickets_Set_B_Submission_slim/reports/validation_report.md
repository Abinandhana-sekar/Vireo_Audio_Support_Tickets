# Validation report

**25/25 automated validation checks passed** (196,655 record-checks).

Method: each headline number is re-computed with plain `csv` + `datetime` loops (no pandas pipeline code) and compared with the pipeline. In addition, `pytest` runs 37 unit/integration tests (`python -m pytest`) covering SLA edges per channel, handle time, legacy UTC conversion, CSAT blank exclusion, attendance, costs, repeat window, roster as-of join, duplicate-name join, shrinkage and bottom-ten ranking.

| test | expected | actual | result | records_tested | note |
|---|---|---|---|---|---|
| Row count equals raw CSV rows | 11750 | 11750 | PASS | 11750 |  |
| Unique ticket_ids | 11750 | 11750 | PASS | 11750 |  |
| CSAT response count (blanks = no response) | 5196 | 5196 | PASS | 11750 |  |
| Average CSAT excludes blanks | 3.326597383 | 3.326597383 | PASS | 5196 | Treating blanks as 0 would give 1.471 |
| SLA breach count (channel targets 15m/2h/4h/8h) | 1064 | 1064 | PASS | 11750 |  |
| Breach credit = Rs 350 x breaches | 372400 | 372400 | PASS | 11750 |  |
| Handle-time rows (resolved_at present) | 11183 | 11183 | PASS | 11183 |  |
| Median handle time (minutes) after legacy UTC->IST fix | 29.0 | 29.0 | PASS | 11183 |  |
| No negative handle time after fix | 0 | 0 | PASS | 11183 | 2309 raw rows were negative before the fix |
| Attendance = resolved + closed | 11183 | 11183 | PASS | 11750 |  |
| Replacement cost = unit cost + Rs 340 per replacement | 3415990.0 | 3415990.0 | PASS | 1896 |  |
| Transfer cost = Rs 305 x transfers | 370575 | 370575 | PASS | 11750 |  |
| Contact cost by channel (policy s4) | 3253060 | 3253060 | PASS | 11750 |  |
| Agent join on agent_id: 44 agents, every ticket mapped | 44 | 44 | PASS | 11750 |  |
| Tickets per agent_id sum to total | 11750 | 11750 | PASS | 11750 |  |
| Shared display name kept as separate agents (Kavya Pandey) | 2 | 2 | PASS | 2 | A3006 and A3029 never merged |
| Roster fully joined (no missing team/tier) | 0 | 0 | PASS | 11750 |  |
| Lot code via order_id equals orders.csv | 0 | 0 | PASS | 7643 |  |
| Repeat-contact count (30-day, same customer+sku) | 2368 | 2368 | PASS | 10592 |  |
| Excess replacements x Rs (unit cost+340) = excess cost | 1212143.038 | 1212143.038 | PASS | 2563 |  |
| Bad-lot replacement cost uses policy formula, not Finance's Rs 2,500 | 1820 | 1820 | PASS | 958 | Policy s5; Finance email figure is not used |
| Bottom-ten has 10 distinct, rank-eligible agents | 10 | 10 | PASS | 10 |  |
| Bottom-ten sorted ascending by shrunk effect | True | True | PASS | 10 |  |
| Shrinkage never increases an effect's magnitude | 0 | 0 | PASS | 44 |  |
| Mean of agent adj. effects weighted by n ~ 0 (residuals centred) | 0.0 | 0.0 | PASS | 4942 |  |

## How often is the tool wrong?
- **Arithmetic metrics:** 0 differences against the independent calculation on every record tested. This proves the code matches *our reading of the policy*, not that the policy definitions match reality.
- **Theme classifier:** 98.4% agreement with its own rule labels on 1,925 held-out tickets. No human-labelled truth exists, so this is NOT an accuracy figure; 749 tickets remain unclassified.
- **Bottom-ten:** the between-agent SD is only 0.05 CSAT points against a per-agent standard error of about 0.09, so membership is inherently uncertain. We therefore report probabilities, not a verdict. No accuracy percentage is claimed.

## Known limitations
- Repeat contact proxies 'same issue' with same customer + same product.
- Replacement flag is agent-set; 496 notes mention a replacement while the flag is N (sensitivity in methodology.md).
- Legacy timestamp fix assumes only resolved_at is UTC (supported by 2,309 negative raw handle times, all legacy, all fixed by +5h30).
- Lot-defect link is a statistical association in support data, not an engineering finding.
