# Methodology

## Definitions (all from support-policy.pdf v3.2)
First response = first_response_at - created_at. Handle time = resolved_at - first_response_at. Breach = first response later than chat 15 min / voice 2 h / social 4 h / email 8 h; credit Rs 350 each.
Attendance = resolved or closed. CSAT blanks excluded. Replacement cost = products.unit_cost_inr + Rs 340. Transfer Rs 305. Contact costs chat 210 / email 260 / voice 520 / social 240. Agent hour Rs 165.
**Timestamps:** legacy_fd `resolved_at` is UTC (policy s9); +5h30 applied. 2,309 raw negative handle times, all legacy, become 0.

## Business goal (calculated, not assumed)
Replacement rate on Pulse 2 True Wireless Earbuds jumps for manufacturing lots 2510, 2511, 2512 (detected automatically: lot-cell rate >= 2x the SKU's median lot-cell rate; ratios 2.8-3.1x).
- Tickets on those lots: 2,563; replaced 958 = **37.4%**.
- Same product, all other lots: 1,817 tickets, **11.4%** replaced.
- Excess replacements = 958 - 2,563 x 0.1139 = **666**.
- Cost each (policy) = 1,480 + 340 = **Rs 1,820** (Finance's Rs 2,500 is not used; blended actual average is Rs 1,802).
- Excess cost = 666 x 1,820 = **Rs 1,212,143** over 18 months; peak quarter 2026Q1 = **Rs 876,756**; latest quarter (2026Q2) Rs 229,205.

| quarter | tickets | replaced | excess | excess_cost_inr |
|---|---|---|---|---|
| 2025Q2 | 6 | 1 | 0.3 | 575.9 |
| 2025Q3 | 1 | 0 | -0.1 | -207.3 |
| 2025Q4 | 385 | 102 | 58.1 | 105813.4 |
| 2026Q1 | 1793 | 686 | 481.7 | 876756.2 |
| 2026Q2 | 378 | 169 | 125.9 | 229204.8 |

**Goal:** bring replacement rate on Pulse 2 lots 2510-12 from 37.4% to 11.4%, worth ~Rs 229,205 per quarter at the latest run-rate and up to Rs 876,756 per quarter if Q1-2026 volumes recur.
Part is a product/supply-chain fix (quality hold, supplier claim); the support-controllable part is triage-before-replace and approval discipline. Training alone will not capture all of it.

**Why not other goals?** Breach credits total Rs 372,400 over 18 months (about Rs 2.5 lakh a year) and breach is 4% on Voice vs 13% on Night shift - a staffing question; transfers cost Rs 370,575; raw CSAT gaps are queue-driven. Replacement excess is the largest single, evidence-backed number.

**Sensitivity to the unreliable replacement flag:** counting a replacement whenever the agent note says so adds 496 replacements (~Rs 8.9 lakh at policy cost, so spend may be understated). Using flag-OR-note, bad-lot rate is 40.1% vs 17.2% baseline and excess falls to ~587 replacements (~Rs 10.7 lakh): the conclusion holds.

**Finance vs Priya:** ticket volume in Q1-26 was 3,442 vs 2,517 in Q4-25 (+37%) but replacements were 865 vs 307 (+182%): volume alone cannot explain it. Excess lot replacements (482 in Q1) account for more than half of the Q1-26 replacement count.

## Bottom-ten method
1. Scoring sample: attended (resolved/closed) tickets with a CSAT response and a non-junk message (4,942 rows). Blanks never become zero.
2. Expected CSAT per ticket from OLS on category, channel, priority, first-routed team, breach, transfer, legacy flag, defective-lot flag and lot x hardware / lot x team interactions. This absorbs queue difficulty, hardware-triage exposure, Tier 2 work and defective-lot anger **without using agent identity**.
3. Agent effect = mean of (actual - expected). Standard error = residual SD (0.95) / sqrt(n).
4. **Empirical-Bayes shrinkage** with DerSimonian-Laird tau^2 (between-agent SD = 0.049): shrunk = effect x tau^2 / (tau^2 + se^2). Small samples shrink more.
5. P(true effect below peers) from the posterior; tiers: >= 90% "Strongest available evidence", >= 75% "Moderate", else "Weak / indistinguishable".
6. Rank-eligibility: >= 30 scored responses (all 44 agents qualify; range 40-234).
7. Tier 2 is scored against the same model (team and category terms put it on its own baseline) but never compared with Tier 1 on volume; handle time shown in days.
8. Two lists are always shown: *lowest observed CSAT* and *strongest evidence of an agent-level opportunity*.

Result: 6 of the 10 lowest raw averages are Tier 2 and 4 are the Chat hardware-triage rota; after adjustment Tier 2 members fall to 1 of the adjusted ten and only 1 agent reaches the 90% level.

## NLP layer (free, local)
TF-IDF term inspection seeded a 13-theme regex lexicon; a char-n-gram logistic regression trained on rule-labelled tickets labels misspelt messages (rule 9,624; ML fallback 1,360; unclassified 749; junk 17). Anger/escalation/repeat cues are keyword flags. Themes are derived from the text, not invented. No API calls.

## Decisions on data traps
Join on agent_id; two Kavya Pandey (A3006 Chat, A3029 Logistics) stay separate. Roster joined as-of ticket date. Legacy money: legacy refunds track order value 1:1 (median ratio 1.00 in both systems) so no unit conversion applied. Same-day same-customer same-product pairs (58 groups) are different contacts, not re-import copies; no exact duplicates exist.
