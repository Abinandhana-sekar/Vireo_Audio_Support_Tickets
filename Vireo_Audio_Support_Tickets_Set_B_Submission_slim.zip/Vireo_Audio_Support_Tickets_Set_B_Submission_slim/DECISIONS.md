# Decisions
Format per decision: Decision / Evidence / Why / Impact.

**1. Bottom ten = two lists, ranked on adjusted + shrunk effect.**
Evidence: raw bottom ten = 6 Tier 2 + 4 Chat rota (hardware share 82-90% / 41-43%). Between-agent SD is 0.05 vs a per-agent standard error ~0.09.
Why: raw averages mostly measure queue difficulty and noise (Neha's email). Shrinkage stops small samples looking extreme. Impact: only 1 agent reaches P>=90%, 6 reach P>=75%; the memo says so rather than naming ten "poor" agents.

**2. Case-mix model includes defective-lot interactions (added after a first run).**
Evidence: without them 4 Chat rota agents were all "strong evidence" (effects -0.19 to -0.31); rota agents score 2.2 on defective-lot tickets vs 3.5 for other chat agents on the same lots, and 40% of their tickets are on those lots.
Why: customer anger from a defective product is not agent skill. Impact: 3 of 4 drop to moderate. This is a modelling choice made after seeing results; it is disclosed here and the unadjusted numbers remain visible in the app.

**3. Tier 2.** Evidence: policy s6. Why: certified multi-touch work, measured in days. Impact: handle time shown in days; Tier 2 volume never compared with Tier 1; scored with team/category terms so they sit on their own baseline.

**4. Junk IVR transcripts.** Evidence: 17 messages with <3 letters or 'test'; Sameer estimated ~40. Why: could not verify more without guessing. Impact: kept in KPIs, excluded from text themes and CSAT scoring; limitation stated.

**5. Missing CSAT.** Evidence: 6,554 blanks (55.8%); policy s8. Why: blank = no response. Impact: never zero; response counts shown next to every average; 249 CSAT values on open/pending tickets are excluded from scoring only.

**6. Migrated (legacy) tickets.** Evidence: 2,309 raw negative handle times, all legacy_fd; policy s9 says resolved_at came from a UTC log. Why: +5h30 removes every negative and gives the same median as helpdesk. Impact: handle time/repeat windows use corrected times. Legacy money: refund/order-value median is 1.00 in both systems, so no unit conversion. Transfers are zero in legacy by design, so transfer rates use helpdesk only.

**7. Duplicate legacy/current records.** Evidence: no duplicate ticket_id or identical rows; 58 same-customer/sku/channel/day groups differ in time, agent and notes. Why: they look like separate contacts. Impact: none removed; flagged in DQ report.

**8. Business goal = Pulse 2 lots 2510-12 replacement rate (37.4% -> 11.4%).**
Evidence: lot-cell replacement 35-38% vs median 12%; found by an automated scan across all SKUs x lots (only Pulse 2 trips it). Why: largest evidence-backed money (Rs 12.1 lakh) vs breach credits Rs 3.7 lakh and transfers Rs 3.7 lakh over 18 months. Impact: the memo frames training as a small part of the fix. Quarterly value stated as Rs 2.3 lakh latest quarter to Rs 8.8 lakh peak because lots are ageing out.

**9. Replacement cost = unit cost + Rs 340 (policy s5), not Rs 2,500.** Evidence: Pulse 2 = Rs 1,820; blended actual Rs 1,802. Impact: Finance's figure overstates by ~39%.

**10. Replacement flag treated as truth, with a sensitivity.** Evidence: 496 notes say replacement while flag N. Impact: cost may be understated by up to ~Rs 8.9 lakh; goal conclusion holds (flag-OR-note excess ~Rs 10.7 lakh).

**11. Order join fallback.** Evidence: 4,107 tickets lack order_id; customer+SKU latest-prior-order recovers 4,015. Impact: lot attribution for 99% of tickets; replacement rates by lot are consistent between direct and fallback joins (see exploration: 26% vs 27% on Pulse 2).

**12. NLP = rules + small classifier, free.** Why: Arjun rejected per-ticket paid calls. Impact: 98% agreement with rules on held-out; 1,261 unclassified.

**13. Repeat contact proxy.** Same customer + SKU within 30 days of resolution, evaluable only when the window is observed (10,592 tickets): 22.4%.

**14. Roster joined as-of ticket date, keyed by agent_id.** Evidence: no agent has >1 roster row in this extract, but the policy says some may. Impact: code handles it; tests cover it.

**15. Rota identification.** The email says "Kavya's four"; we infer A3004-A3007 (4 Chat agents including Kavya Pandey A3006 with ~42% hardware share and ~40% defective-lot tickets). Inference, not confirmed.

**16. Training budget.** Evidence: effects are small. Impact: recommend spending <= Rs 1 lakh of Rs 4 lakh; the trainer fee is an assumption, agent time uses Rs 165/hour.
