# AI usage disclosure

| Item | Detail |
|---|---|
| Assistant | Claude (Anthropic), free claude.ai account, with its built-in code-execution sandbox. Used for analysis, code, documents and QA. |
| Run-time models | **None.** The tool makes no API calls and uses no LLM. |
| Libraries | Python, pandas, numpy, scipy, scikit-learn (TF-IDF, logistic regression), Streamlit, Plotly, pytest, reportlab. All open source. |
| External data | None. Only the supplied pack. |
| Cost | Development: Rs 0 beyond the free Claude plan. Running the tool: Rs 0 (vs Finance's Rs 5 x 12,000 = Rs 60,000 for per-ticket calls). |
| Human review | The submitter must review the numbers and memo before sending; the AI was not asked to verify beyond its own tests. |

## Accepted
Policy-based definitions; legacy UTC fix; as-of roster join; empirical-Bayes shrinkage; automated lot-anomaly scan; independent re-computation validation; rules + char-n-gram theme model.

## Rejected / discarded
- **Ranking 44 agents on raw average CSAT** - measures queue, not people.
- **Finance's Rs 2,500 replacement cost** - policy gives unit cost + Rs 340.
- **Per-ticket LLM calls** (cost, Finance objection) and sentiment APIs.
- **First lot-detection attempt** compared each lot with all other lots (which include the bad lots) and found nothing; replaced with a median-based baseline.
- **First scoring model without defective-lot interactions** - it labelled four Chat rota agents "strong evidence". Adding interactions (a judgement made after seeing results, disclosed in DECISIONS.md #2) reduced that to one.
- **Duplicate-removal of "same customer/day" tickets** - they are distinct contacts.
- **Workspace files of unknown origin:** partway through the session, extra source files and a PROGRESS.md appeared in the project directory that the assistant had not written. They were not used; the project was rebuilt from scratch in a fresh directory.

## Changed by human/assistant iteration
The Streamlit text was changed from hard-coded claims to computed ones after the scoring model changed; memo numbers were checked against pipeline output.

## Limits of this disclosure
Prompts are summarised in `prompts_used.md`. The tool's outputs were tested against an independent recomputation, not against ground truth.
