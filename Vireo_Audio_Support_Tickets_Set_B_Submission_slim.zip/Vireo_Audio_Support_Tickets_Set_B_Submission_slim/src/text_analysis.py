"""Lightweight, free NLP layer: rule lexicon (seeded from TF-IDF term inspection) + a char-n-gram
logistic-regression that learns from confidently rule-labelled tickets so misspelt messages
('canel ordr', 'prduct arrived damaegd') still get a theme. No external APIs, no per-ticket LLM calls."""
import re
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

THEMES = {  # order matters: first match wins; specific before generic
    "Damaged / wrong item": r"damag|crack|crush|broken|wrong (item|product)|different product|dented",
    "Double charge / payment": r"charged (two|twice|2)|two times|twice.*(card|charged)|double payment|deducted|payment (failed|debited)|no order",
    "Cancellation": r"cancel|ordered by mistake|wrong pincode|change.*address|address change",
    "Delivery / tracking": r"not delivered|not received my order|haven.t received|tracking|shipped since|stuck on shipped|courier|undelivered|promised 24|pickup|no one showed",
    "Refund pending": r"refund|money back|want my money|my money",
    "Battery / charging": r"charg|battery|dies|drain|lasts|backup|won.t turn on|dead|swollen|heat",
    "Audio quality": r"audio|sound|hiss|distort|crackl|static|mic|hear me|volume|one direction|bass|tinny|echo|mono",
    "Connectivity / pairing": r"pair|bluetooth|connect|disconnect|cutting out|drops",
    "App / firmware": r"\bapp\b|firmware|fw update|update stuck|crash|otp|log ?in|locked out|password",
    "Warranty / repair": r"warrant|repair|service cent|rma|\bservice\b",
    "Billing / invoice / coupon": r"invoice|gst|bill\b|coupon|promo|price|discount",
    "Pre-sale / compatibility": r"compatib|will this|does .* work with|before i buy|work with|survive",
    "Replacement request": r"replac|exchange|new unit",
}
ANGER = r"pathetic|worst|ridiculous|unacceptable|fed up|disgust|last time i buy|never again|very poor|disappointing|nothing changed|someone senior|escalate|posting on|twitter|consumer|legal|emailed twice|waste|cheat|fraud|useless|angry|furious|joke"
ESCALATE = r"someone senior|escalate|posting on|twitter|consumer|legal|manager"
REPEATING = r"emailed twice|again|still waiting|third time|already tried|nothing changed|2nd time|second time"


def clean(msg):
    s = re.sub(r"^\s*\[IVR transcript\]", "", str(msg)).lower()
    return re.sub(r"\s+", " ", s).strip()


def rule_theme(s):
    for th, pat in THEMES.items():
        if re.search(pat, s):
            return th
    return None


def analyse(t, seed=7):
    """Adds: msg_clean, theme_rule, theme, theme_source, angry, escalation_cue, repeat_cue.
    Returns (tickets, info) where info has the self-check accuracy of the fallback classifier."""
    t = t.copy()
    t["msg_clean"] = t.customer_message.map(clean)
    t["theme_rule"] = t.msg_clean.map(rule_theme)
    t["angry"] = t.msg_clean.str.contains(ANGER, regex=True)
    t["escalation_cue"] = t.msg_clean.str.contains(ESCALATE, regex=True)
    t["repeat_cue"] = t.msg_clean.str.contains(REPEATING, regex=True)
    ok = t.theme_rule.notna() & ~t.junk_message
    vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), min_df=3, sublinear_tf=True)
    X = vec.fit_transform(t.msg_clean)
    y = t.theme_rule
    idx = np.where(ok)[0]
    tr, te = train_test_split(idx, test_size=0.2, random_state=seed, stratify=y.iloc[idx])
    clf = LogisticRegression(max_iter=300, C=5).fit(X[tr], y.iloc[tr])
    acc = float((clf.predict(X[te]) == y.iloc[te]).mean())
    pred = clf.predict(X); prob = clf.predict_proba(X).max(axis=1)
    use_ml = t.theme_rule.isna() & ~t.junk_message & (prob >= 0.30)
    t["theme"] = np.where(t.theme_rule.notna(), t.theme_rule, np.where(use_ml, pred, "Unclassified / low information"))
    t.loc[t.junk_message, "theme"] = "Junk / empty message"
    t["theme_source"] = np.where(t.junk_message, "junk", np.where(t.theme_rule.notna(), "rule", np.where(use_ml, "ml-fallback", "none")))
    # low-information: very short, no theme -> report alongside junk
    t["low_info"] = t.junk_message | ((t.theme == "Unclassified / low information") & (t.msg_clean.str.len() < 25))
    info = dict(heldout_agreement=acc, n_train=len(tr), n_test=len(te),
                rule_labelled=int(t.theme_rule.notna().sum()), ml_labelled=int(use_ml.sum()),
                unclassified=int((t.theme == "Unclassified / low information").sum()),
                junk=int(t.junk_message.sum()), low_info=int(t.low_info.sum()))
    return t, info


def theme_table(t, by=None):
    """Mean CSAT / replacement / handle time by theme (CSAT blanks excluded)."""
    g = t[~t.junk_message].groupby(by or "theme")
    return g.agg(tickets=("ticket_id", "size"), csat_n=("has_csat", "sum"), csat=("csat_score", "mean"),
                 replaced=("replaced", "mean"), angry=("angry", "mean"),
                 median_handle_h=("handle_hours", "median")).sort_values("tickets", ascending=False).reset_index()


def top_terms(t, n=12, mask=None):
    """Top TF-IDF terms for a subset (used for 'example themes' in agent drill-down)."""
    sub = t if mask is None else t[mask]
    sub = sub[~sub.junk_message]
    if len(sub) < 5:
        return []
    v = TfidfVectorizer(ngram_range=(1, 2), stop_words="english", token_pattern=r"[a-z]{3,}", min_df=2, max_features=2000)
    X = v.fit_transform(sub.msg_clean)
    s = np.asarray(X.sum(0)).ravel()
    return list(np.array(v.get_feature_names_out())[np.argsort(-s)[:n]])
