"""Single entry point used by the app, reports and tests."""
from . import data_loader as dl, text_analysis as ta, metrics as mt, scoring as sc, validation as vd


def load_all(data_dir=None):
    raw = dl.read_raw(data_dir) if data_dir else dl.read_raw()
    t = dl.build(raw=raw)
    t, info = ta.analyse(t)
    goal = mt.goal_calc(t)
    t["bad_lot"] = (t.product_sku == goal["sku"]) & t.lot_month.isin(goal["lots"])
    agents = mt.agent_table(t)
    ranking, meta = sc.build_ranking(t, agents)
    dq = dl.data_quality(raw, t)
    val = vd.run_checks(t, raw["agents"], ranking, goal) if data_dir is None else None
    return dict(raw=raw, t=t, info=info, goal=goal, agents=agents, ranking=ranking, meta=meta, dq=dq, val=val)
