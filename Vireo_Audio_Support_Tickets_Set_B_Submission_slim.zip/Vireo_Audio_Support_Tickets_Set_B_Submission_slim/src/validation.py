"""Independent re-computation of headline metrics (plain csv/datetime loops, no pandas pipeline reuse)
and comparison with the pipeline output. Produces the validation report table."""
import csv
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from . import utils as U

F = "%Y-%m-%d %H:%M"


def _raw_rows(data_dir=U.DATA):
    with open(data_dir / "tickets.csv", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def run_checks(t, agents_raw, ranking, goal, data_dir=U.DATA):
    rows = _raw_rows(data_dir)
    prods = {r["sku"]: float(r["unit_cost_inr"]) for r in csv.DictReader(open(data_dir / "products.csv", newline=""))}
    out = []

    def chk(name, expected, actual, n, note="", tol=1e-9):
        try:
            ok = abs(float(expected) - float(actual)) <= tol
        except (TypeError, ValueError):
            ok = expected == actual
        out.append(dict(test=name, expected=expected, actual=actual, result="PASS" if ok else "FAIL", records_tested=n, note=note))

    chk("Row count equals raw CSV rows", len(rows), len(t), len(rows))
    chk("Unique ticket_ids", len({r["ticket_id"] for r in rows}), t.ticket_id.nunique(), len(rows))
    # CSAT excludes blanks
    sc = [float(r["csat_score"]) for r in rows if r["csat_score"].strip()]
    chk("CSAT response count (blanks = no response)", len(sc), int(t.has_csat.sum()), len(rows))
    chk("Average CSAT excludes blanks", round(sum(sc) / len(sc), 9), round(t.csat_score.mean(), 9), len(sc), "Treating blanks as 0 would give %.3f" % (sum(sc) / len(rows)))
    # SLA breach
    breach = 0; neg_raw = 0; ht = []
    for r in rows:
        c = datetime.strptime(r["created_at"], F); fr = datetime.strptime(r["first_response_at"], F)
        if (fr - c) > timedelta(minutes=U.SLA_MINUTES[r["channel"]]):
            breach += 1
        if r["resolved_at"].strip():
            res = datetime.strptime(r["resolved_at"], F)
            if r["source_system"] == "legacy_fd":
                res += timedelta(minutes=330)
            ht.append((res - fr).total_seconds() / 60)
            if (datetime.strptime(r["resolved_at"], F) - fr).total_seconds() < 0:
                neg_raw += 1
    chk("SLA breach count (channel targets 15m/2h/4h/8h)", breach, int(t.breach.sum()), len(rows))
    chk("Breach credit = Rs 350 x breaches", breach * 350, t.breach_credit_inr.sum(), len(rows))
    chk("Handle-time rows (resolved_at present)", len(ht), int(t.handle_min.notna().sum()), len(ht))
    chk("Median handle time (minutes) after legacy UTC->IST fix", round(float(np.median(ht)), 6), round(float(t.handle_min.median()), 6), len(ht))
    chk("No negative handle time after fix", 0, int((t.handle_min < 0).sum()), len(ht), f"{neg_raw} raw rows were negative before the fix")
    chk("Attendance = resolved + closed", sum(r["status"] in ("resolved", "closed") for r in rows), int(t.attended.sum()), len(rows))
    # costs
    rep = [r for r in rows if r["replacement_issued"] == "Y"]
    exp = sum(prods[r["product_sku"]] + 340 for r in rep)
    chk("Replacement cost = unit cost + Rs 340 per replacement", exp, t.replacement_cost_inr.sum(), len(rep))
    chk("Transfer cost = Rs 305 x transfers", 305 * sum(int(r["transfers"]) for r in rows), t.transfer_cost_inr.sum(), len(rows))
    cc = {"chat": 210, "email": 260, "voice": 520, "social": 240}
    chk("Contact cost by channel (policy s4)", sum(cc[r["channel"]] for r in rows), t.contact_cost_inr.sum(), len(rows))
    # agent joins
    byid = {}
    for r in rows:
        byid[r["agent_id"]] = byid.get(r["agent_id"], 0) + 1
    chk("Agent join on agent_id: 44 agents, every ticket mapped", 44, t.agent_id.nunique(), len(rows))
    chk("Tickets per agent_id sum to total", sum(byid.values()), int(ranking.tickets.sum()), len(rows))
    names = pd.read_csv(data_dir / "agents.csv").groupby("name").agent_id.nunique()
    dup = names[names > 1].index.tolist()
    a = ranking[ranking.agent_name.isin(dup)]
    chk("Shared display name kept as separate agents (Kavya Pandey)", 2, len(a), len(a), "A3006 and A3029 never merged")
    chk("Roster fully joined (no missing team/tier)", 0, int(t.agent_team.isna().sum() + t.agent_tier.isna().sum()), len(t))
    # order join
    om = {r["order_id"]: r["lot_code"] for r in csv.DictReader(open(data_dir / "orders.csv", newline=""))}
    direct = [(r["ticket_id"], om[r["order_id"]]) for r in rows if r["order_id"] in om]
    tl = t.set_index("ticket_id").lot_code
    chk("Lot code via order_id equals orders.csv", 0, sum(tl[i] != lot for i, lot in direct), len(direct))
    # repeat contact (independent O(n^2) on a customer subset)
    by = {}
    for r in rows:
        by.setdefault((r["customer_id"], r["product_sku"]), []).append(r)
    end = max(datetime.strptime(r["created_at"], F) for r in rows)
    exp_rep = ev = 0
    for k, lst in by.items():
        for r in lst:
            if r["status"] not in ("resolved", "closed") or not r["resolved_at"].strip():
                continue
            res = datetime.strptime(r["resolved_at"], F) + (timedelta(minutes=330) if r["source_system"] == "legacy_fd" else timedelta())
            if res + timedelta(days=30) > end:
                continue
            ev += 1
            if any(res < datetime.strptime(o["created_at"], F) <= res + timedelta(days=30) for o in lst):
                exp_rep += 1
    chk("Repeat-contact count (30-day, same customer+sku)", exp_rep, int(t.repeat_contact.sum()), ev)
    # goal arithmetic
    chk("Excess replacements x Rs (unit cost+340) = excess cost", round(goal["excess_replacements"] * goal["cost_each"], 4), round(goal["excess_cost_inr"], 4), goal["bad_tickets"])
    chk("Bad-lot replacement cost uses policy formula, not Finance's Rs 2,500", 1820, goal["cost_each"], goal["bad_replaced"], "Policy s5; Finance email figure is not used")
    # ranking sanity
    bo = ranking[ranking.eligible.fillna(False)].sort_values("shrunk_effect").head(10)
    chk("Bottom-ten has 10 distinct, rank-eligible agents", 10, bo.agent_id.nunique(), 10)
    chk("Bottom-ten sorted ascending by shrunk effect", True, bool(bo.shrunk_effect.is_monotonic_increasing), 10)
    chk("Shrinkage never increases an effect's magnitude", 0, int((ranking.shrunk_effect.abs() > ranking.adj_effect.abs() + 1e-12).sum()), len(ranking))
    chk("Mean of agent adj. effects weighted by n ~ 0 (residuals centred)", 0.0, round(float((ranking.adj_effect * ranking.n_scored).sum() / ranking.n_scored.sum()), 6), int(ranking.n_scored.sum()), tol=1e-6)
    return pd.DataFrame(out)


def summary(df):
    return f"{int((df.result == 'PASS').sum())}/{len(df)} automated validation checks passed"
