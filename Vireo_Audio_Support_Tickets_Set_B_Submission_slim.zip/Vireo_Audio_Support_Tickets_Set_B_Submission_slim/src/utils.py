"""Constants taken from data/support-policy.pdf (v3.2). Nothing here is invented."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"

SLA_MINUTES = {"chat": 15, "voice": 120, "social": 240, "email": 480}      # policy s3
BREACH_CREDIT_INR = 350                                                      # policy s3
CONTACT_COST = {"chat": 210, "email": 260, "voice": 520, "social": 240}     # policy s4
TRANSFER_COST = 305                                                          # policy s4
AGENT_HOUR_COST = 165                                                        # policy s4
LOGISTICS_PER_REPLACEMENT = 340                                              # policy s5
GOODWILL_CAP = 500                                                           # policy s5
LEGACY_RESOLVED_UTC_OFFSET_MIN = 330   # legacy resolved_at is UTC; helpdesk shows IST (policy s9)
ATTENDANCE_STATUSES = ("resolved", "closed")
HARDWARE_CATEGORIES = ("Charging & Battery", "Audio Quality", "Warranty & Repair")
REPEAT_WINDOW_DAYS = 30                                                      # policy s10
MIN_CSAT_RESPONSES = 30


def inr(x):
    return f"Rs {x:,.0f}"


def pct(x, d=1):
    return f"{100 * x:.{d}f}%"
