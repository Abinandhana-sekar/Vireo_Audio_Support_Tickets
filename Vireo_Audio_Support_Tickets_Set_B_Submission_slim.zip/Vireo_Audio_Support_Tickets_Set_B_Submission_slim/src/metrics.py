"""KPI, cost and agent-table calculations. Definitions follow support-policy.pdf v3.2."""
import numpy as np
import pandas as pd
from . import utils as U


def kpis(t):
    att = t[t.attended]
    h = att[att.handle_min.notna()]
    hd = t[t.source_system == "helpdesk"]
    ev = t[t.repeat_evaluable]
    return dict(
        tickets=len(t), attended=int(t.attended.sum()),
        csat_responses=int(t.has_csat.sum()),
        csat_response_rate=float(t.has_csat.sum() / max(len(t), 1)),
        avg_csat=float(t.csat_score.mean()),          # pandas mean skips NaN = blanks excluded
        median_handle_h=float(h.handle_hours.median()) if len(h) else np.nan,
        breach_rate=float(t.breach.mean()) if len(t) else np.nan,
        breaches=int(t.breach.sum()),
        breach_credit_inr=float(t.breach_credit_inr.sum()),
        repeat_rate=float(ev.repeat_contact.mean()) if len(ev) else np.nan,
        repeat_evaluable=int(len(ev)),
        transfer_rate_helpdesk=float((hd.transfers > 0).mean()) if len(hd) else np.nan,
        transfer_cost_inr=float(t.transfer_cost_inr.sum()),
        replacements=int(t.replaced.sum()),
        replacement_rate=float(t.replaced.mean()) if len(t) else np.nan,
        replacement_cost_inr=float(t.replacement_cost_inr.sum()),
        refunds=int(t.refunded.sum()),
        refund_inr=float(t.refund_amount_inr.sum()),
        contact_cost_inr=float(t.contact_cost_inr.sum()),
    )


def quarterly(t):
    g = t.groupby("quarter")
    return g.agg(tickets=("ticket_id", "size"), replacements=("replaced", "sum"),
                 replacement_rate=("replaced", "mean"), replacement_cost_inr=("replacement_cost_inr", "sum"),
                 breach_credit_inr=("breach_credit_inr", "sum"), avg_csat=("csat_score", "mean")).reset_index()


def agent_table(t):
    """One row per agent_id (never by name). Handle time in hours; Tier 2 also in days."""
    rows = []
    weeks = max((t.created_at.max() - t.created_at.min()).days / 7, 1)
    for aid, g in t.groupby("agent_id"):
        last = g.sort_values("created_at").iloc[-1]
        att = g[g.attended]
        hd = g[g.source_system == "helpdesk"]
        c = g.csat_score.dropna()
        rows.append(dict(
            agent_id=aid, agent_name=last.agent_name, team=last.agent_team, site=last.agent_site,
            shift=last.agent_shift, tier=int(last.agent_tier),
            tickets=len(g), attended=len(att), attended_per_week=len(att) / weeks,
            csat_n=len(c), csat_avg=c.mean() if len(c) else np.nan,
            csat_pct_1_2=(c <= 2).mean() if len(c) else np.nan, csat_pct_4_5=(c >= 4).mean() if len(c) else np.nan,
            median_handle_h=att.handle_hours.median(), median_handle_days=att.handle_hours.median() / 24,
            breach_rate=g.breach.mean(), transfer_rate=(hd.transfers > 0).mean() if len(hd) else np.nan,
            replacement_rate=g.replaced.mean(), refund_rate=g.refunded.mean(),
            hardware_share=g.hw_category.mean(), angry_share=g.angry.mean() if "angry" in g else np.nan,
            closed_share=(g.status == "closed").mean(), open_pending=int(g.status.isin(["open", "pending"]).sum()),
            top_channel=g.channel.value_counts().idxmax()))
    return pd.DataFrame(rows)


def detect_lot_anomalies(t, min_n=100, ratio=2.0):
    """Find SKU x manufacturing-lot-month cells whose replacement rate is >= `ratio` x the SKU's MEDIAN
    lot-cell rate (median is robust to the bad lots themselves). Data-driven; nothing hard-coded."""
    k = t[t.lot_month.notna()]
    cells = k.groupby(["product_sku", "lot_month"]).agg(tickets=("ticket_id", "size"), replacement_rate=("replaced", "mean")).reset_index()
    med = cells[cells.tickets >= 30].groupby("product_sku").replacement_rate.median().rename("median_cell_rate")
    cells = cells.merge(med, on="product_sku")
    cells["ratio"] = cells.replacement_rate / cells.median_cell_rate.clip(lower=1e-9)
    return cells[(cells.tickets >= min_n) & (cells.ratio >= ratio)].sort_values(["product_sku", "lot_month"]).reset_index(drop=True)


def goal_calc(t):
    """Primary business goal, computed from data + policy formula (unit cost + Rs 340)."""
    an = detect_lot_anomalies(t)
    sku = an.product_sku.iloc[0]; lots = list(an.lot_month)
    is_bad = (t.product_sku == sku) & t.lot_month.isin(lots)
    other = t[(t.product_sku == sku) & t.lot_month.notna() & ~is_bad]
    base = other.replaced.mean()
    bad = t[is_bad]
    unit = t.loc[t.product_sku == sku, "unit_cost_inr"].iloc[0]
    cost_each = unit + U.LOGISTICS_PER_REPLACEMENT
    expected = len(bad) * base
    excess = bad.replaced.sum() - expected
    per_q = bad.groupby("quarter").agg(tickets=("ticket_id", "size"), replaced=("replaced", "sum"))
    per_q["excess"] = per_q.replaced - per_q.tickets * base
    per_q["excess_cost_inr"] = per_q.excess * cost_each
    q_peak = per_q.excess_cost_inr.idxmax()
    all_rep = t[t.replaced]
    return dict(sku=sku, product=t.loc[t.product_sku == sku, "product_name"].iloc[0], lots=lots,
                bad_tickets=len(bad), bad_replaced=int(bad.replaced.sum()), bad_rate=bad.replaced.mean(),
                baseline_rate=base, baseline_n=len(other), unit_cost=unit, cost_each=cost_each,
                excess_replacements=excess, excess_cost_inr=excess * cost_each,
                per_quarter=per_q, peak_quarter=q_peak, peak_quarter_excess_cost=per_q.excess_cost_inr.max(),
                avg_replacement_cost_all=all_rep.replacement_cost_inr.mean(),
                finance_assumed_cost=2500, total_replacement_cost=all_rep.replacement_cost_inr.sum())
