"""Load, clean and join the Vireo support data. Rows are FLAGGED, never silently dropped."""
import re
import numpy as np
import pandas as pd
from .utils import (DATA, SLA_MINUTES, BREACH_CREDIT_INR, CONTACT_COST, TRANSFER_COST,
                    LOGISTICS_PER_REPLACEMENT, LEGACY_RESOLVED_UTC_OFFSET_MIN,
                    ATTENDANCE_STATUSES, REPEAT_WINDOW_DAYS, HARDWARE_CATEGORIES)

TS = ["created_at", "first_response_at", "resolved_at"]


def read_raw(data_dir=DATA):
    return {k: pd.read_csv(data_dir / f"{k}.csv") for k in ["tickets", "agents", "orders", "customers", "products"]}


def is_junk_message(msg) -> bool:
    """Failed transcript / no content: <3 letters once the IVR tag is removed, or a 'test' ticket."""
    s = re.sub(r"^\s*\[IVR transcript\]", "", str(msg)).strip().lower()
    return sum(c.isalpha() for c in s) < 3 or s in {"test", "testing", "[line dropped]"}


def roster_asof(tickets, agents):
    """Join roster by agent_id AS OF the ticket date (an agent may have several roster rows).
    Falls back to the nearest row if none covers the date (flagged)."""
    a = agents.copy()
    a["from_date"] = pd.to_datetime(a["from_date"]); a["to_date"] = pd.to_datetime(a["to_date"])
    tk = tickets[["ticket_id", "agent_id", "created_at"]].copy()
    tk["cd"] = tk["created_at"].dt.normalize()
    m = tk.merge(a, on="agent_id", how="left")
    m["covered"] = (m.from_date <= m.cd) & (m.to_date.isna() | (m.to_date >= m.cd))
    m["gap"] = (m.from_date - m.cd).abs().dt.days.where(~m.covered, 0)
    m = m.sort_values(["ticket_id", "covered", "gap"], ascending=[True, False, True]).drop_duplicates("ticket_id")
    return m[["ticket_id", "name", "site", "team", "shift", "tier", "covered"]].rename(columns={
        "name": "agent_name", "team": "agent_team", "shift": "agent_shift", "site": "agent_site",
        "tier": "agent_tier", "covered": "roster_covers_date"})


def attach_orders(t, orders):
    """order_id join; fallback = latest order by the same customer+sku on/before the ticket date."""
    o = orders.copy()
    o["order_date"] = pd.to_datetime(o["order_date"])
    o["lot_month"] = o["lot_code"].str.extract(r"-(\d{4})-")[0]
    cols = ["lot_code", "lot_month", "order_date", "order_value_inr"]
    d = t[["ticket_id", "order_id"]].merge(o[["order_id"] + cols], on="order_id", how="left").set_index("ticket_id")
    d["join_method"] = np.where(d.lot_code.notna(), "order_id", "unmatched")
    miss = t.loc[t.ticket_id.isin(d.index[d.lot_code.isna()]), ["ticket_id", "customer_id", "product_sku", "created_at"]]
    cand = miss.merge(o.rename(columns={"sku": "product_sku"})[["customer_id", "product_sku"] + cols],
                      on=["customer_id", "product_sku"], how="inner")
    cand = cand[cand.order_date <= cand.created_at.dt.normalize()]
    cand = cand.sort_values(["ticket_id", "order_date"]).drop_duplicates("ticket_id", keep="last").set_index("ticket_id")
    for c in cols:
        d.loc[cand.index, c] = cand[c]
    d.loc[cand.index, "join_method"] = "customer+sku fallback"
    return d.drop(columns="order_id").reset_index()


def flag_repeats(t):
    """Policy s10: customer contacts again about the same issue within 30 days of resolution.
    'Same issue' is proxied by same customer + same product_sku (no issue key exists)."""
    t = t.copy()
    end = t.created_at.max()
    base = t.loc[t.attended & t.resolved_at.notna(), ["ticket_id", "customer_id", "product_sku", "resolved_at"]]
    nxt = t[["ticket_id", "customer_id", "product_sku", "created_at"]].rename(columns={"ticket_id": "later_id"})
    m = base.merge(nxt, on=["customer_id", "product_sku"])
    m = m[(m.created_at > m.resolved_at) & (m.created_at <= m.resolved_at + pd.Timedelta(days=REPEAT_WINDOW_DAYS))]
    t["repeat_contact"] = t.ticket_id.isin(m.ticket_id)
    # window must be fully observable to evaluate (data ends at `end`)
    t["repeat_evaluable"] = t.attended & t.resolved_at.notna() & (t.resolved_at + pd.Timedelta(days=REPEAT_WINDOW_DAYS) <= end)
    t.loc[~t.repeat_evaluable, "repeat_contact"] = False
    return t


def build(data_dir=DATA, raw=None):
    raw = raw or read_raw(data_dir)
    t = raw["tickets"].copy()
    for c in TS:
        t[c] = pd.to_datetime(t[c], errors="coerce")
    legacy = t.source_system.eq("legacy_fd")
    # policy s9: legacy resolved_at was rebuilt from a UTC log -> convert to IST
    t.loc[legacy, "resolved_at"] = t.loc[legacy, "resolved_at"] + pd.Timedelta(minutes=LEGACY_RESOLVED_UTC_OFFSET_MIN)
    t["first_response_min"] = (t.first_response_at - t.created_at).dt.total_seconds() / 60
    t["handle_min"] = (t.resolved_at - t.first_response_at).dt.total_seconds() / 60
    t["handle_hours"] = t.handle_min / 60
    t["sla_target_min"] = t.channel.map(SLA_MINUTES)
    t["breach"] = t.first_response_min > t.sla_target_min
    t["attended"] = t.status.isin(ATTENDANCE_STATUSES)
    t["csat_score"] = pd.to_numeric(t.csat_score, errors="coerce")
    t.loc[~t.csat_score.between(1, 5), "csat_score"] = np.nan
    t["has_csat"] = t.csat_score.notna()
    t["replaced"] = t.replacement_issued.eq("Y")
    t["refunded"] = t.refund_amount_inr.notna()
    t["junk_message"] = t.customer_message.map(is_junk_message)
    t = t.merge(roster_asof(t, raw["agents"]), on="ticket_id", how="left")
    t = t.merge(attach_orders(t, raw["orders"]), on="ticket_id", how="left")
    p = raw["products"][["sku", "product_name", "family", "unit_cost_inr"]]
    t = t.merge(p, left_on="product_sku", right_on="sku", how="left").drop(columns="sku")
    t["replacement_cost_inr"] = np.where(t.replaced, t.unit_cost_inr + LOGISTICS_PER_REPLACEMENT, 0.0)
    t["breach_credit_inr"] = np.where(t.breach, BREACH_CREDIT_INR, 0)
    t["transfer_cost_inr"] = t.transfers * TRANSFER_COST
    t["contact_cost_inr"] = t.channel.map(CONTACT_COST)
    t["hw_category"] = t.category.isin(HARDWARE_CATEGORIES)
    t["month"] = t.created_at.dt.to_period("M").astype(str)
    t["quarter"] = t.created_at.dt.to_period("Q").astype(str)
    t["pl2_lot"] = (t.product_sku == "VA-EB-PL2") & t.lot_month.notna()
    return flag_repeats(t)


def data_quality(raw, t):
    tk, ag, od = raw["tickets"], raw["agents"], raw["orders"]
    legacy = t.source_system.eq("legacy_fd")
    rows = []
    add = lambda c, n, tr: rows.append({"check": c, "rows_affected": int(n), "treatment": tr})
    raw_ht = (pd.to_datetime(tk.resolved_at) - pd.to_datetime(tk.first_response_at)).dt.total_seconds()
    add("Total tickets", len(tk), "All retained")
    add("Duplicate ticket_id", tk.ticket_id.duplicated().sum(), "None found")
    add("Fully duplicated rows", tk.duplicated().sum(), "None found")
    near = t.assign(_d=t.created_at.dt.date).duplicated(["customer_id", "product_sku", "channel", "_d"], keep=False)
    add("Same customer+sku+channel+day (candidate legacy/current re-import duplicates)", near.sum(),
        "Retained: pairs differ in time, agent, category and notes, so they are separate contacts; no exact re-import copies found")
    add("Missing agent_id / agent_id not in roster", (tk.agent_id.isna() | ~tk.agent_id.isin(ag.agent_id)).sum(), "None")
    add("Agents with >1 roster row", (ag.agent_id.value_counts() > 1).sum(), "None in this extract; roster still joined as-of ticket date")
    add("Display names shared by 2+ agent_ids", (ag.groupby("name").agent_id.nunique() > 1).sum(), "Kavya Pandey = A3006 and A3029; every join uses agent_id")
    add("Tickets created outside roster row date range", (~t.roster_covers_date.fillna(False)).sum(), "None")
    add("Missing first_response_at", t.first_response_at.isna().sum(), "None")
    add("Missing resolved_at (all open/pending)", t.resolved_at.isna().sum(), "Kept; excluded from handle time only")
    add("Resolved/closed but resolved_at missing", (t.attended & t.resolved_at.isna()).sum(), "None")
    add("RAW negative handle time (legacy: resolved_at in UTC, others IST)", (raw_ht < 0).sum(), "FIXED: legacy resolved_at +5h30 per policy s9")
    add("Negative handle time after fix", (t.handle_min < 0).sum(), "None")
    add("First response before creation", (t.first_response_min < 0).sum(), "None")
    add("CSAT outside 1-5", (tk.csat_score.notna() & ~tk.csat_score.between(1, 5)).sum(), "None")
    add("CSAT blank (no response)", tk.csat_score.isna().sum(), "Excluded from averages, never counted as zero")
    add("Invalid replacement flag (not Y/N)", (~tk.replacement_issued.isin(["Y", "N"])).sum(), "None")
    add("Refund <= 0, or refund without reason code (or vice versa)", ((tk.refund_amount_inr <= 0) | (tk.refund_amount_inr.notna() != tk.refund_reason_code.notna())).sum(), "None")
    add("Refund AND replacement on one ticket (policy s5 says escalate)", (t.refunded & t.replaced).sum(), "Retained; listed for Team Lead/Finance")
    rl = t[t.refunded & t.order_value_inr.notna()]
    r = (rl.refund_amount_inr / rl.order_value_inr).groupby(rl.source_system).median()
    add("Legacy money unit check: median refund / order value (legacy %.2f, helpdesk %.2f)" % (r.get("legacy_fd", np.nan), r.get("helpdesk", np.nan)),
        (t.refunded & legacy).sum(), "No conversion needed: legacy refunds are already on a rupee scale")
    add("Ticket without order_id", tk.order_id.isna().sum(), "Fallback join customer+sku (only used for lot analysis)")
    add("  recovered by fallback join", (t.join_method == "customer+sku fallback").sum(), "Lot attributed with fallback flag")
    add("  still unmatched", (t.join_method == "unmatched").sum(), "No lot attribution")
    add("order_id quoted but missing from orders", (tk.order_id.notna() & ~tk.order_id.isin(od.order_id)).sum(), "None")
    om = tk.merge(od, on="order_id")
    add("Quoted order has different customer_id or sku", ((om.customer_id_x != om.customer_id_y) | (om.product_sku != om.sku)).sum(), "None")
    add("Ticket created before the order date", (t.order_date.notna() & (t.created_at.dt.normalize() < t.order_date)).sum(), "Retained (mostly pre-sale or fallback-join noise); lot unaffected for order_id joins")
    add("customer_id not in customers / sku not in products", (~tk.customer_id.isin(raw["customers"].customer_id) | ~tk.product_sku.isin(raw["products"].sku)).sum(), "None")
    add("Legacy (Freshdesk) tickets", legacy.sum(), "Retained; timestamps fixed; transfers not recorded in legacy so transfer metrics use helpdesk only")
    add("Junk / empty customer_message (failed transcript, '-', '...', 'test')", t.junk_message.sum(), "Retained in all KPIs (not an agent issue); excluded from text themes only")
    add("IVR transcripts present (voice)", t.customer_message.str.startswith("[IVR").sum(), "Retained")
    add("Agent note says replacement raised but flag = N", (t.agent_notes.str.contains(r"replacement raised|rplc|new unit shipped", case=False, regex=True) & ~t.replaced).sum(), "Flag used as source of truth; logged as limitation")
    return pd.DataFrame(rows)
