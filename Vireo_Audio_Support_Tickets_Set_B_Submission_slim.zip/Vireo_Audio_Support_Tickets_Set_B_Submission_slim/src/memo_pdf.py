"""Render memo_to_priya.md to a one-page PDF with reportlab:  python -m src.memo_pdf"""
import re
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from .utils import ROOT


def main():
    ss = getSampleStyleSheet()
    st = ParagraphStyle("b", parent=ss["Normal"], fontName="Helvetica", fontSize=8.6, leading=10.6, spaceAfter=3.5)
    doc = SimpleDocTemplate(str(ROOT / "memo_to_priya.pdf"), pagesize=A4, leftMargin=34, rightMargin=34, topMargin=28, bottomMargin=24)
    flow = []
    for para in (ROOT / "memo_to_priya.md").read_text(encoding="utf-8").strip().split("\n\n"):
        p = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", para.replace("&", "&amp;").replace("<", "&lt;"))
        p = p.replace("\u2013", "-").replace("\u00b1", "+/-").replace("\u00d7", "x").replace("\u2014", "-")
        flow += [Paragraph(p, st), Spacer(1, 1)]
    doc.build(flow)


if __name__ == "__main__":
    main()
