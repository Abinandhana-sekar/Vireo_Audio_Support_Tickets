"""Bottom-ten methodology: case-mix adjusted, empirical-Bayes-shrunk agent CSAT effect."""
import numpy as np
import pandas as pd
from scipy.stats import norm
from .utils import MIN_CSAT_RESPONSES

COVARS = ["category", "channel", "priority", "assigned_team"]


def design_matrix(d):
    X = pd.get_dummies(d[COVARS], drop_first=True, dtype=float)
    X["breach"] = d.breach.astype(float)
    X["transferred"] = (d.transfers > 0).astype(float)
    X["legacy"] = (d.source_system == "legacy_fd").astype(float)
    bad = d.get("bad_lot", pd.Series(False, index=d.index)).astype(float)
    X["pl2_bad_lot"] = bad
    # defective-lot customers are far angrier on hardware faults and in the chat queue -> interactions
    X["bad_lot_x_hw"] = bad * d.hw_category.astype(float)
    for tm in sorted(d.assigned_team.unique())[1:]:
        X[f"bad_lot_x_{tm}"] = bad * (d.assigned_team == tm).astype(float)
    X.insert(0, "const", 1.0)
    return X


def scoring_sample(t):
    """CSAT-bearing, attended (resolved/closed) tickets with a usable message. Open/pending rows that
    carry a CSAT (anomalous per policy s8) and junk transcripts are excluded from scoring only."""
    return t[t.has_csat & t.attended & ~t.junk_message].copy()


def dersimonian_laird_tau2(effects, se):
    if len(effects) < 2:
        return 0.0
    w = 1 / se**2
    mu = np.sum(w * effects) / np.sum(w)
    q = np.sum(w * (effects - mu) ** 2)
    k = len(effects)
    c = np.sum(w) - np.sum(w**2) / np.sum(w)
    return max(0.0, (q - (k - 1)) / c)


def score_agents(t, min_n=MIN_CSAT_RESPONSES, prob_cut=0.90, effect_cut=-0.10):
    d = scoring_sample(t)
    X = design_matrix(d)
    y = d.csat_score.values
    beta, *_ = np.linalg.lstsq(X.values, y, rcond=None)
    d["expected_csat"] = X.values @ beta
    d["resid"] = y - d.expected_csat
    sd = d.resid.std(ddof=X.shape[1])
    g = d.groupby("agent_id").agg(n_scored=("resid", "size"), raw_csat=("csat_score", "mean"),
                                   expected_csat=("expected_csat", "mean"), adj_effect=("resid", "mean"))
    g["se"] = sd / np.sqrt(g.n_scored)
    el = g.n_scored >= min_n
    tau2 = dersimonian_laird_tau2(g.loc[el, "adj_effect"].values, g.loc[el, "se"].values)
    g["tau2"] = tau2
    shrink = tau2 / (tau2 + g.se**2) if tau2 > 0 else 0.0
    g["shrinkage"] = shrink
    g["shrunk_effect"] = g.adj_effect * g.shrinkage
    post_sd = np.sqrt(1 / (1 / max(tau2, 1e-9) + 1 / g.se**2))
    g["post_sd"] = post_sd
    g["p_below_peers"] = norm.cdf(-g.shrunk_effect / post_sd)
    g["p_above_peers"] = 1 - g.p_below_peers
    g["eligible"] = el
    return g.reset_index(), dict(tau=float(np.sqrt(tau2)), resid_sd=float(sd), n_rows=len(d),
                                 beta=dict(zip(X.columns, beta)), min_n=min_n)


def build_ranking(t, agents, **kw):
    """Merge agent_table + scoring; produce two distinct lists:
    lowest_observed  = lowest raw CSAT average (what Priya's dashboard would show)
    training_priority = lowest shrunk, case-mix-adjusted effect, with evidence tiers."""
    t = t.copy()
    sc, meta = score_agents(t, **kw)
    a = agents.merge(sc, on="agent_id", how="left")
    a["raw_rank"] = a.csat_avg.rank(method="min")
    el = a.eligible.fillna(False)
    a["adj_rank"] = a.shrunk_effect.where(el).rank(method="min")
    # within-team rank among eligible
    a["team_rank"] = a.where(el).groupby("team").shrunk_effect.rank(method="min")
    def tier(r):
        if not r.eligible:
            return "Insufficient data"
        if r.p_below_peers >= 0.90:
            return "Strongest available evidence"
        if r.p_below_peers >= 0.75:
            return "Moderate evidence"
        return "Weak / indistinguishable from peers"
    a["evidence"] = a.apply(tier, axis=1)
    a["hw_exposure"] = np.where(a.hardware_share >= 0.60, "High (hardware/warranty queue)", np.where(a.hardware_share >= 0.35, "Medium", "Low"))
    return a, meta


def bottom_ten_observed(a):
    return a.sort_values("csat_avg").head(10)


def bottom_ten_adjusted(a):
    return a[a.eligible.fillna(False)].sort_values("shrunk_effect").head(10)


def top_five_adjusted(a):
    return a[a.eligible.fillna(False)].sort_values("shrunk_effect", ascending=False).head(5)


def recommend(t, a, agent_id):
    """Plain-language training recommendation for one agent. Correlation only - never claims causation."""
    r = a[a.agent_id == agent_id].iloc[0]
    peers = a[(a.team == r.team) & (a.agent_id != agent_id)]
    g = t[t.agent_id == agent_id]
    d = scoring_sample(g)
    issues, areas = [], []
    def gap(col):
        sd = peers[col].std()
        return (r[col] - peers[col].mean()) / sd if sd and sd > 0 else 0.0
    if gap("breach_rate") > 1.0:
        issues.append(f"first-response breach rate {r.breach_rate:.1%} vs team {peers.breach_rate.mean():.1%}"); areas.append("queue discipline / first-response habits")
    if r.tier == 1 and gap("transfer_rate") > 1.0:
        issues.append(f"transfer rate {r.transfer_rate:.1%} vs team {peers.transfer_rate.mean():.1%}"); areas.append("routing & ownership (fewer hand-offs)")
    if gap("replacement_rate") > 1.0:
        issues.append(f"replacement rate {r.replacement_rate:.1%} vs team {peers.replacement_rate.mean():.1%}"); areas.append("troubleshoot-before-replace playbook")
    if gap("median_handle_h") > 1.0:
        issues.append(f"median handle time {r.median_handle_h:.1f}h vs team {peers.median_handle_h.mean():.1f}h"); areas.append("resolution efficiency")
    if r.get("adj_effect", 0) < -0.10:
        issues.append(f"CSAT {r.adj_effect:+.2f} vs case-mix expectation")
        areas.append("de-escalation & empathy coaching (listen-in sessions)")
    if not issues:
        issues = ["no metric clearly outside peer range"]; areas = ["none required - monitor"]
    ctx = []
    if r.hardware_share >= 0.35:
        ctx.append(f"{r.hardware_share:.0%} of tickets are hardware/warranty (hard queue)")
    if r.tier == 2:
        ctx.append("Tier 2: judge on resolution days and peers inside Tier 2 only")
    bad = g.get("bad_lot", pd.Series(False, index=g.index)).mean()
    if bad >= 0.25:
        ctx.append(f"{bad:.0%} of tickets involve the defective Pulse 2 lots")
    conf = {"Strongest available evidence": "Medium", "Moderate evidence": "Low-Medium"}.get(r.evidence, "Low")
    if r.get("n_scored", 0) < 60:
        conf = "Low"
    return dict(agent=f"{r.agent_name} ({agent_id})", issue="; ".join(issues), evidence=f"n={int(r.n_scored)} CSAT responses, P(below peers)={r.p_below_peers:.0%}, evidence tier: {r.evidence}",
                context="; ".join(ctx) or "standard queue", training="; ".join(areas), confidence=conf)
